__version__ = '0.0.1'  # TODO: Update when releasing
