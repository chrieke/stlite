class HTTPServerRequest(object):
    pass
